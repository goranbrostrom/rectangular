predict <- function(in.year = NULL, sex = "all",
                    pop = NULL, 
                    fertility = NULL,
                    mortality = NULL,
                    inmigr = NULL,
                    random = TRUE){
    ## Given a year 'in.year', this function predicts
    ## population size by age at the end of the given year,
    ## or, at Jan. 1 the year 'in.year + 1'.

    ## The default is to assume that the fertility and mortality
    ## patterns are the same as the given year.

    ## inmig is assumed to be zero by default. Should be given as
    ## absolute numbers.

    if (!is.null(in.year)){
        if (in.year < 1970) stop("in.year must be at least 1970.")
        if (in.year > 2007) stop("in.year must be at most 2007.")
        
        pop <- get.pop(sex, in.year - 1) # NOTE!
        pop.mean <- (pop + get.pop(sex, in.year)) / 2
        deaths <- get.deaths(sex, in.year)
        births <- get.births(sex, in.year)
        inmig  <- get.inmig(sex, in.year)
        females <- (get.pop("females", in.year - 1) +
                    get.pop("females", in.year)) / 2
        fertility <- births / females
        mortality <- deaths / pop.mean
        inmigr <- get.inmig(sex, in.year)
    }else{
        if (any(c(is.null(pop),
                  is.null(fertility),
                  is.null(mortality)))) stop("Too many 'NULL'!")
        if (is.null(inmigr)) inmigr <- numeric(length(pop))
    }

    ## Update:
    ## (needs some more sophistication! later....
    if (random){# randomly
        deaths <- rpois(length(mortality), mortality * pop.mean)
        pop.out <- pop - deaths
        pop.out <- pop.out + inmigr
        births <- sum(rpois(length(fertility), fertility * females))
        pop.out <- c(births, pop.out)
        pop.out <- pop.out[-length(pop.out)]
    }else{# non-randomly
        pop.out <- (1 - mortality) * pop.mean
        pop.out <- pop.out + inmigr
        births <- sum(fertility * females)
        pop.out <- c(births, pop.out)
        pop.out <- pop.out[-length(pop.out)]
    }
    pop.out
}    
