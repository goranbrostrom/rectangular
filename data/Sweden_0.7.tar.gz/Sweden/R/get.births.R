get.births <- function(sex = c("all", "males", "females"),
                       years = c(1969, 2007)){
    sex <- sex[1]
    if (!(sex %in% c("all", "males", "females")))
      stop("Parameter 'sex' has wrong value")
    if (length(years) == 1) years <- c(years, years)
    if (length(years) == 2){
        years <- c(min(years), max(years))
        if (years[1] < 1969) years[1] <- 1969
        if (years[2] > 2007) years[2] <- 2007
        start <- years[1] - 1969 + 1
        slut <- years[2] - 1969 + 1
    }else{
        stop ("years has wrong length (should be 1 or 2)")
    }
    ##births6907 <- read.csv("born6907.csv", sep = ",", header = TRUE)
    ##births6907 <- births6907[, -c(1, 2)]
    ##for (x in names(births6907)) births6907[, x] <-
    ##  as.numeric(as.character(births6907[, x]))
    ##names(births6907) <- substr(names(births6907), 2, 5)
    ##save(births6907, file = "births6907.RData")
    data("births6907")
    males <- births6907[seq(1, NROW(births6907), 2),
                       start:slut,
                       drop = FALSE]
    ##rownames(males) <- as.character(14:49)
    ##if (sex == "males") return(males)
    ##
    females <- births6907[seq(2, NROW(births6907), 2),
                         start:slut,
                         drop = FALSE]
    ##rownames(females) <- rownames(males)
    if (sex == "females") {
        res <- females
    }else{
        if (sex == "males"){
            res <- males
        }else{
            res <- males + females
        }
    }
    ##
    res <- as.matrix(res)
    res <- rbind(matrix(0, nrow = 14, ncol = (slut - start + 1)), res)
    res <- rbind(res, matrix(0, nrow = 56, ncol = (slut - start + 1)))
    rownames(res) <- as.character(0:105)
    res
}
