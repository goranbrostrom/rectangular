get.pop <- function(sex = c("all", "females", "males"),
                    years = c(1969, 2007)){
    data(pop18602050)
    sex <- sex[1]
    if (!(sex %in% c("all", "males", "females")))
      stop("Parameter 'sex' has wrong value")
    if (length(years) == 1) years <- c(years, years)
    if (length(years) == 2){
        years <- c(min(years), max(years))
        if (years[1] < 1860) years[1] <- 1860
        if (years[2] > 2050) years[2] <- 2050
    }else{
        stop("years has wrong length (should be 1 or 2)")
    }
    
    if (sex == "all"){
        res <- pop18602050$males + pop18602050$females
    }else{
        if (sex == "females"){
            res <- pop18602050$females
        }else{
            if (sex == "males"){
                res <- pop18602050$males
            }else{
                stop("'sex' has an illegal value")
            }
        }
    }
    left <- years[1] - 1860 + 1
    right <- years[2] - 1860 + 1
    res <- as.matrix(res[, left:right, drop = FALSE])
    if ((years[1] >= 1969) & (years[2] <= 2007)){
        ## Fake population in ages 100:105 by "halving" each year:
        r100 <- res[101, ]
        res[101, ] <- r100 / 1.96875
        for (i in 1:5){
            res[101+i, ] <- res[100+i, ] / 2
        }
    }
    res
}
