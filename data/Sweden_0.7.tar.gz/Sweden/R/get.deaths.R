get.deaths <- function(sex = c("all", "males", "females"),
                       years = c(1969, 2007)){
    sex <- sex[1]
    if (!(sex %in% c("all", "males", "females")))
      stop("Parameter 'sex' has wrong value")
    if (length(years) == 1) years <- c(years, years)
    if (length(years) == 2){
        years <- c(min(years), max(years))
        if (years[1] < 1969) years[1] <- 1969
        if (years[2] > 2007) years[2] <- 2007
        start <- years[1] - 1969 + 1
        slut <- years[2] - 1969 + 1
    }else{
        stop ("years has wrong length (should be 1 or 2)")
    }
    
    ##deaths6907 <- read.csv("dead6907.csv", sep = ",", header = TRUE)
    ##deaths6907 <- deaths6907[, -c(1, 2)]
    ##return(deaths6907)
    ##for (x in names(deaths6907))
    ##  deaths6907[, x] <- as.numeric(as.character(deaths6907[, x]))
    ##names(deaths6907) <- substr(names(deaths6907), 2, 5)
    ##save(deaths6907, file = "deaths6907.RData")

    data(deaths6907)
    if (sex == "males"){
        res <- deaths6907[seq(1, NROW(deaths6907), 2),
                          start:slut,
                          drop = FALSE]
    }else{
        if (sex == "females"){
            res <- deaths6907[seq(2, NROW(deaths6907), 2),
                              start:slut,
                              drop = FALSE]
        }else{
            males <- deaths6907[seq(1, NROW(deaths6907), 2),
                               start:slut,
                               drop = FALSE]
            females <- deaths6907[seq(2, NROW(deaths6907), 2),
                                 start:slut,
                                 drop = FALSE]
            res <- males + females
        }
    }

    res <- as.matrix(res)
    res <- rbind(res, matrix(0, nrow = 5, ncol = (slut - start + 1)))
    rownames(res) <- as.character(0:105)
    colnames(res) <- as.character(years[1]:years[2])
    ## Fake deaths in ages 100:105 by "halving" each year:
    r100 <- res[101, ]
    res[101, ] <- round(r100 / 1.96875)
    for (i in 1:5){
        res[101+i, ] <- round(res[100+i, ] / 2)
    }

    res

}
