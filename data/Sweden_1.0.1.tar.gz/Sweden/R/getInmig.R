getInmig <- function(sex = c("all", "males", "females"),
                      years = 1968:2014, ages = 0:100){
    sex <- sex[1]
    if (!(sex %in% c("all", "males", "females")))
      stop("Parameter 'sex' has wrong value")

    if (min(years) < 1968 | max(years) > 2014) stop("Wrong years\n")
    if (min(ages) < 0 | max(ages) > 100) stop("Wrong ages\n")
    years <- as.character(years)
    ages <- as.character(ages)
    
    if (sex == "females"){
        dat <- Sweden::inmig$females[ages, years]
    }else if (sex == "males"){
        dat <- Sweden::inmig$males[ages, years]
    }else{
        dat <- Sweden::inmig$females[ages, years] +
            Sweden::inmig$males[ages, years]
    }

    dat
}
