getBirths <- function(sex = c("all", "males", "females"),
                       years = 1968:2014, ages = 14:49){
    
    sex <- sex[1]
    if (!(sex %in% c("all", "males", "females")))
        stop("Parameter 'sex' has wrong value\n")
    
    if (min(years) < 1968 | max(years) > 2014) stop("Wrong years\n")
    if (min(ages) < 14 | max(ages) > 49) stop("Wrong ages\n")
    years <- as.character(years)
    ages <- as.character(ages)
    
    if (sex == "females") {
        dat <- Sweden::births$females[ages, years]
    }else if (sex == "males"){
        dat <- Sweden::births$males[ages, years]
    }else{
        dat <- Sweden::births$females[ages, years] +
            Sweden::births$males[ages, years]
    }
    ##

    dat
}
